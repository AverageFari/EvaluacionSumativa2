package com.example.evaluacionsumativa2_vicentefarias;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Crud extends AppCompatActivity {
    UsuariosSQLite usuariossql=null;
    TextView nombre = null;
    TextView apellido = null;
    TextView fecha = null;
    TextView ciudad = null;
    int ID = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crud);
        this.ID = (TextView)findViewById(R.id.txtID)
        this.nombre = (TextView)findViewById(R.id.txtNombre);
        this.apellido = (TextView)findViewById(R.id.txtApellido;
        this.fecha = (TextView)findViewById(R.id.txtEdad);
        this.ciudad = (TextView)findViewById(R.id.txtCiudad);


        usuariossql = new UsuariosSQLite(this);
    }

    public void onClickEliminar(){
        usuariossql.sentencia_eliminar(ID);
    }
    public void onClickModificar(){
        //NOMBRE="+a+", APELLIDO="+b+", FECHANAC="+c+", CIUDAD="+d+" WHERE ID="+id")"
        usuariossql.sentencia_actualizar(nombre.toString(),.toString(),fecha.toString(),ciudad.toString(),ID);
    }
}