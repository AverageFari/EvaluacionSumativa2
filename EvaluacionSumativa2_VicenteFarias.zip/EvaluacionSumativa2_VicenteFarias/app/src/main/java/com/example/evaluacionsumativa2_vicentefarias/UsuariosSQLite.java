package com.example.evaluacionsumativa2_vicentefarias;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UsuariosSQLite extends SQLiteOpenHelper {
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE USUARIOS (" +
                "ID INT PRIMARY KEY AUTOINCREMENT," +
                " NOMBRE VARCHAR(50)," +
                "APELLIDO VARCHAR()," +
                "FECHANAC DATE"+
                "CIUDAD"+
                " EMAIL VARCHAR(50)," +
                "TELEFONO VARCHAR (20)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    //MODIFICAR ESTAS WEAS
    public void sentencia_crear(String nom, String ap,String fec, String ciu, String mail, String tel ){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO USUARIOS(NOMBRE, APELLIDO, FECHANAC, CIUDAD, EMAIL, TELEFONO) VALUES("+nom+","+ap+","+fec+","+ciu+","+mail+","+tel+")");
        db.close();
    }
    public void sentencia_eliminar(int id){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM USUARIOS WHERE ID = "+id);
        db.close();
    }
    public void sentencia_actualizar(String a, String b, String c, String d, int id){
        SQLiteDatabase db = getWritableDatabase();
        //No se puede cambiar el mail
        db.execSQL("UPDATE USUARIOS SET NOMBRE="+a+", APELLIDO="+b+", FECHANAC="+c+", CIUDAD="+d+" WHERE ID="+id")");
        db.close();
    }
}
