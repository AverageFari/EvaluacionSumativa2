package com.example.evaluacionsumativa2_vicentefarias;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Registro extends AppCompatActivity {
    UsuariosSQLite usuariossql=null;
    TextView nombre = null;
    TextView apellido = null;
    TextView fecha = null;
    TextView ciudad = null;
    TextView correo = null;
    TextView telefono = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        this.nombre = (TextView)findViewById(R.id.txtNombre);
        this.apellido = (TextView)findViewById(R.id.txtApellido;
        this.fecha = (TextView)findViewById(R.id.txtEdad);
        this.ciudad = (TextView)findViewById(R.id.txtCiudad);
        this.correo = (TextView)findViewById(R.id.txtCorreo);
        this.telefono = (TextView)findViewById(R.id.txtTelefono);

        usuariossql = new UsuariosSQLite(this);
    }

    public void onClickRegistro(){
        usuariossql.sentencia_crear(this.nombre.toString(),this.apellido.toString(),this.fecha.toString(),this.ciudad.toString(),this.correo.toString(),this.telefono.toString());
    }
}